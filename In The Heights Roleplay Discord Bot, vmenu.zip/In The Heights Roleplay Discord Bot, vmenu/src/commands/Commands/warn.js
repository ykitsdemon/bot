const fs = require('fs');
const { SlashCommandBuilder, guilds } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('Warn a user')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Select the user to warn')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the warning')
                .setRequired(true)),
    async execute(interaction) {
        const userToWarn = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason');

        const warnRoleId = process.env.warnRoleID;
        if (!interaction.member.roles.cache.has(warnRoleId)) {
            const errorEmbed = {
                title: 'Permission Error',
                description: 'You do not have permission to use this command.',
                color: 0xff0000,
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
            };

            interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return;
        }

        let warnings = JSON.parse(fs.readFileSync('warnings.json'));
        let warningID = Math.floor(100000 + Math.random() * 900000);
        while (warningID in warnings) {
            warningID = Math.floor(100000 + Math.random() * 900000);
        }

        const newWarning = {
            id: warningID,
            reason: reason,
            timestamp: new Date().toJSON(),
            moderator: interaction.user.id,
        };

        warnings[userToWarn.id] = warnings[userToWarn.id] || [];
        warnings[userToWarn.id].push(newWarning);

        fs.writeFileSync('warnings.json', JSON.stringify(warnings, null, 4));

        userToWarn.send({
            embeds: [
                {
                    title: 'You have received a warning',
                    description: `You were warned`,
                    fields: [
                        {
                            name: 'Moderator ',
                            value: `** <@${interaction.user.id}> **`,
                        },
                        {
                            name: 'Warning Reason',
                            value: `**${reason}**`,
                        },
                        {
                            name: 'Warning ID',
                            value: `# **${warningID}**`,
                        },
                        {
                            name: 'Total Warnings',
                            value: `**${warnings[userToWarn.id].length.toString()} / 3 warnings**`,
                        },
                        
                    ],
                    color: 0xff0000,
                    footer: {
                        text: 'Warning system  • ' + process.env.footerText,
                    },
                },
            ],
        })
        .then(() => {
            const successEmbed = {
                title: 'Warning Issued',
                description: `**Warning ID: ${warningID}** - ${userToWarn} has been warned for: ${reason}`,
                color: 0x00ff00,
                footer: {
                    text: 'Success • ' + process.env.footerText,
                },
            };

            interaction.reply({ embeds: [successEmbed] });
        })
        .catch(error => {
            console.error(`Failed to send a DM to ${userToWarn.tag}: ${error.message}`);
            const errorEmbed = {
                title: 'Warning Issued with DM Error',
                description: `**Warning ID: ${warningID}** - ${userToWarn} has been warned for: ${reason}. \n __**but there was an issue sending a DM.**__`,
                color: 0xff0000,
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
            };

            interaction.reply({ embeds: [errorEmbed] });
        });
    },
};