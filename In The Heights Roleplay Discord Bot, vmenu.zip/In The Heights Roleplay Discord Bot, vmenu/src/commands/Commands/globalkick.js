const { SlashCommandBuilder } = require('discord.js');

const allowedRoleId = process.env.globalKickRole;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('globalkick')
        .setDescription('Kick a user from all guilds the bot is in')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to globally kick')
            .setRequired(true))
        .addStringOption(option => option
            .setName('reason')
            .setDescription('Reason for the global kick')
            .setRequired(true)),
    async execute(interaction) {
        const member = interaction.member;
        const allowedRole = interaction.guild.roles.cache.get(allowedRoleId);
        if (!member.roles.cache.has(allowedRoleId)) {
            const errorEmbed = {
                color: 0xff0000,
                title: 'Permission Error',
                description: 'You do not have permission to use this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                }
            };

            return interaction.reply({ embeds: [errorEmbed] });
        }

        const userToKick = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (userToKick.id === interaction.user.id) {
            const selfKickErrorEmbed = {
                color: 0xff0000,
                title: 'Self-Kick Error',
                description: 'You cannot globally kick yourself using this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • NexusGuard',
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };
            return interaction.reply({ embeds: [selfKickErrorEmbed] });
        }

        interaction.client.guilds.cache.forEach(async (guild) => {
            try {
                const memberToKick = guild.members.cache.get(userToKick.id);
                if (memberToKick) {
                    await memberToKick.kick(reason);
                }
            } catch (error) {
                console.error(`Failed to kick user ${userToKick.id} from guild ${guild.name}: ${error.message}`);
            }
        });

        const successEmbed = {
            color: 0x00ff00,
            title: 'User Globally Kicked',
            description: `Successfully globally kicked <@${userToKick.id}> from all guilds the bot is in.`,
            fields: [
                {
                    name: 'Reason',
                    value: reason,
                },
                {
                    name: 'Kicked from Guilds',
                    value: ` ${interaction.client.guilds.cache.size} / ${interaction.client.guilds.cache.size} guilds`,
                },
            ],
            timestamp: new Date(),
            footer: {
                text: 'Globally Kicked • ' + process.env.footerText,
            },
            thumbnail: {
                url: userToKick.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
            },
        };

        interaction.reply({ embeds: [successEmbed] });
    },
};
