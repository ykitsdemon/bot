const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unassignrole')
        .setDescription('Unassign a role from a member')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Select a member to unassign a role from')
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('The role you want to unassign from the member')
                .setRequired(true)),
    async execute(interaction) {
        const unassignRole = process.env.unassignRole;
        const hasPermission = interaction.member.roles.cache.has(unassignRole);

        const embed = {
            title: 'Unassign Role',
            color: hasPermission ? 0x00ff00 : 0xff0000,
            footer: {
                text: 'Unassign Role • '+ process.env.footerText,
            },
        };

        if (!hasPermission) {
            embed.description = 'You do not have permission to unassign roles from users.';
            interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        const member = interaction.options.getMember('user');
        const role = interaction.options.getRole('role');
        const userHighestRole = interaction.member.roles.highest;
        if (userHighestRole.comparePositionTo(role) < 0) {
            embed.description = 'You cannot unassign a role higher than your highest role.';
            interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }
        if (!member.roles.cache.has(role.id)) {
            embed.description = `${member} doesn't have that role.`;
            interaction.reply({ embeds: [embed], ephemeral: true });
        } else {
            member.roles.remove(role).catch(console.error);
            embed.description = `${role} has been unassigned from ${member}`;
            interaction.reply({ embeds: [embed] });
        }
    },
};
