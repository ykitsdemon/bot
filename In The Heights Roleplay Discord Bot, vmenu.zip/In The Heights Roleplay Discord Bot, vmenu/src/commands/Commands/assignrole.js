const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('assignrole')
        .setDescription('Assign a role to a member')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Select a member to assign a role to')
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('The role you want to give to the member')
                .setRequired(true)),
    async execute(interaction) {
        const assignRole = process.env.assignRole;
        const hasPermission = interaction.member.roles.cache.has(assignRole);
    
        const embed = {
            title: 'Assigned Role',
            color: hasPermission ? 0x00ff00 : 0xff0000,
            footer: {
                text: 'Assign Role • ' + process.env.footerText,
            },
        };

        if (!hasPermission) {
            embed.description = 'You do not have permission to assign roles to users.';
            interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        const member = interaction.options.getMember('user');
        const role = interaction.options.getRole('role');

        const userHighestRole = interaction.member.roles.highest;
        if (userHighestRole.comparePositionTo(role) < 0) {
            embed.description = 'You cannot assign a role higher than your highest role.';
            interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        if (member.roles.cache.has(role.id)) {
            embed.description = `${member} already has that role.`;
        } else {
            member.roles.add(role).catch(console.error);
            embed.description = `${role} has been assigned to ${member}`;
        }

        interaction.reply({ embeds: [embed] });
    },
};
