const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('checkban')
        .setDescription('Check if a user is banned in the server')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to check for banning')
            .setRequired(true)),
    async execute(interaction) {
        const userToCheck = interaction.options.getUser('user');
        const member = interaction.guild.members.cache.get(userToCheck.id);
        const embed = {
            title: 'Check Ban Status',
            color: 0x3498DB, 
            footer: {
                text: 'Check Ban • '+ process.env.footerText,
            },
        };


        const isBanned = await interaction.guild.bans.fetch()
            .then(bans => bans.some(ban => ban.user.id === userToCheck.id));

        if (isBanned) {
            embed.description = `<@${userToCheck.id}> is banned in this server.`;
        } else {
            embed.description = `<@${userToCheck.id}> is not banned in this server.`;
        }

        interaction.reply({ embeds: [embed] });
    },
};
