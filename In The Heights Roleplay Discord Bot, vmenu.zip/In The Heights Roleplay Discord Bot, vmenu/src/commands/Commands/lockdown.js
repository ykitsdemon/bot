const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lockdown')
    .setDescription('Lockdown the current channel.')
    .addChannelOption(option => option.setName('channel').setDescription('The channel to lock.')),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const lockdownRoleID = process.env.lockdownChannelRoleID; // Replace with your specific role ID
    const error = new EmbedBuilder()
    .setColor('Blurple')
    .setDescription('You do not have the required permissions to use this command. ')
    .setTimestamp()
    .setTitle('Permission Error')
    .setFooter({ text: `Permission Error • ${process.env.footerText}` });

    if (!interaction.member.roles.cache.has(lockdownRoleID)) {
      return interaction.reply({ embeds: [error], ephemeral: true });
    }

    const already = new EmbedBuilder()
    .setColor('Blurple')
    .setDescription('This Channel Already Seems to be locked Down ')
    .setTimestamp()
    .setTitle('Error')
    .setFooter({ text: `Error • ${process.env.footerText}` });

    if (channel.permissionsFor(interaction.guild.roles.everyone).has(PermissionsBitField.Flags.SendMessages) === false) {
      return interaction.reply({ embeds: [already], ephemeral: true });
    }

    await channel.permissionOverwrites.create(interaction.guild.roles.everyone, {
      SendMessages: false
    });

    const embed = new EmbedBuilder()
      .setColor('#2f3136')
      .setTitle(`The channel has been locked down.`)
      .setDescription(`Channel Name: ${channel}`)
      .setFooter({ text: `Locked Down • ${process.env.footerText}` })
      .setTimestamp();

    await interaction.reply({ ephemeral: true, embeds: [embed] });
  },
};
