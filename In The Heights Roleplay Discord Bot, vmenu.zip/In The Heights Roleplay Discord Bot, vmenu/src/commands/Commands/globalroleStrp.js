const { SlashCommandBuilder } = require('discord.js');

const roleid = process.env.GlobalRoleStrip;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('globalrolestrip')
        .setDescription('Remove all roles from a user in all guilds the bot is in')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to remove roles from')
            .setRequired(true)),
    async execute(interaction) {
        const member = interaction.member;
        const allowedRole = interaction.guild.roles.cache.get(roleid);
       
        if (!member.roles.cache.has(roleid)) {
            const errorEmbed = {
                color: 0xff0000,
                title: 'Permission Error',
                description: 'You do not have permission to use this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };

            return interaction.reply({ embeds: [errorEmbed] });
        }

        const userToRolestrip = interaction.options.getUser('user');
        const bot = interaction.client;

        let successfulStrips = 0;
        let failedStrips = 0;

        for (const [guildID, guild] of bot.guilds.cache) {
            try {
                const member = await guild.members.fetch(userToRolestrip.id);
                await member.roles.set([]);
                successfulStrips++;
            } catch (error) {
                console.error(`Failed to strip roles from user ${userToRolestrip.id} in guild ${guild.name}: ${error.message}`);
                failedStrips++;
            }
        }

        const totalGuilds = bot.guilds.cache.size;

        const successEmbed = {
            color: 0x00ff00,
            title: 'Global Role Stripped',
            description: `Successfully stripped all roles from <@${userToRolestrip.id}> in ${successfulStrips} / ${totalGuilds} guilds. `,
            timestamp: new Date(),
            footer: {
                text: 'Role Stripped • ' + process.env.footerText,
            },
        };

        interaction.reply({ embeds: [successEmbed] });
    },
};
