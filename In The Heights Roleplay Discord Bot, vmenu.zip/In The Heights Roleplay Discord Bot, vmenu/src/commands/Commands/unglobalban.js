const { SlashCommandBuilder } = require('discord.js');

const allowedRoleId = process.env.unGlobalBanRoleID;
const GuildOnlyCommand = (interaction) => {
    if (!interaction.inGuild()) {
        const embed = {
            title: 'Command Error',
            color: 0xff0000,
            description: 'This command can only be used in a server (guild), not in DMs.',
            footer: {
                text: 'Error •' + process.env.footerText,
            },
        };

        interaction.reply({ embeds: [embed], ephemeral: true });
        return false;
    }
    return true;
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('globalunban')
        .setDescription('Unban a user from all guilds the bot is in')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to globally unban')
            .setRequired(true))
        .addStringOption(option => option
            .setName('reason')
            .setDescription('Reason for the global unban')
            .setRequired(true)),
    async execute(interaction) {
        if (!GuildOnlyCommand(interaction)) {
            return;
        }
        const member = interaction.member;

        if (!member.roles.cache.has(allowedRoleId)) {
            const errorEmbed = {
                color: 0xff0000,
                title: 'Permission Error',
                description: 'You do not have permission to use this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • NexusGuard',
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };

            return interaction.reply({ embeds: [errorEmbed] });
        }

        const userToUnban = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (userToUnban.id === interaction.user.id) {
            const selfUnbanErrorEmbed = {
                color: 0xff0000,
                title: 'Self-Unban Error',
                description: 'You cannot unban yourself using this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };

            return interaction.reply({ embeds: [selfUnbanErrorEmbed] });
        }

        const unbannedGuilds = [];
        const bans = await interaction.guild.bans.fetch();

        interaction.client.guilds.cache.forEach(async (guild) => {
            try {
                if (bans.has(userToUnban.id)) {
                    await guild.bans.remove(userToUnban, { reason });
                    unbannedGuilds.push(guild.name);
                }
            } catch (error) {
                console.error(`Failed to unban user ${userToUnban.id} from guild ${guild.name}: ${error.message}`);
            }
        });

        const successEmbed = {
            color: 0x00ff00,
            title: 'User Globally Unbanned',
            description: `Successfully globally unbanned <@${userToUnban.id}>`,
            fields: [
                {
                    name: 'Reason',
                    value: reason,
                },
                {
                    name: 'Unbanned in Guilds',
                    value: `${interaction.client.guilds.cache.size} / ${interaction.client.guilds.cache.size}`,
                },
            ],
            timestamp: new Date(),
            footer: {
                text: 'Globally Unbanned • '+ process.env.footerText,
            },
            thumbnail: {
                url: userToUnban.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
            },
        };

        interaction.reply({ embeds: [successEmbed] });
    },
};
