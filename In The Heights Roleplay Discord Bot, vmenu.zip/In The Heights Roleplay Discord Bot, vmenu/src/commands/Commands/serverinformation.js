const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('serverinfo')
        .setDescription('Get information about the server'),
    async execute(interaction) {
        const guild = interaction.guild;

        guild.members.fetch(guild.ownerId) 
            .then((owner) => {
                const ownerMention = owner.user ? `<@${owner.user.id}>` : 'Unknown';
                const serverThumbnail = guild.iconURL({ format: 'png', dynamic: true, size: 512 });
                const serverBanner = guild.bannerURL({ format: 'png', size: 512 });
                const serverInfoEmbed = {
                    title: ':desktop: SERVER INFORMATION :desktop:',
                    fields: [
                        {
                            name: 'Owner',
                            value: `${ownerMention}`,
                        },
                        {
                            name: 'Server name',
                            value: `\`\`\`${guild.name}\`\`\``,
                        },
                        {
                            name: 'Server ID',
                            value: `\`\`\`${guild.id}\`\`\``,
                        },
                        {
                            name: 'Members',
                            value: `\`\`\`${guild.memberCount}\`\`\``,
                        },
                        {
                            name: 'Roles',
                            value: `\`\`\`${guild.roles.cache.size}\`\`\``,
                        },
                        {
                            name: 'Channels',
                            value: `\`\`\`${guild.channels.cache.size}\`\`\``,
                        },
                        {
                            name: 'Created on (MM/DD/YYYY)',
                            value: `\`\`\`${new Date(guild.createdTimestamp).toLocaleString('en-US', { timeZone: 'UTC' })}\`\`\``,
                        },
                    ],
                    thumbnail: {
                        url: serverThumbnail,
                    },
                    image: {
                        url: serverBanner,
                    },
                    footer: {
                        Text: 'Server Information • '+process.env.footerText,
                    },
                    color: 0x3498DB, 
                };

                interaction.reply({ embeds: [serverInfoEmbed] });
            })
            .catch((error) => {
                console.error('Error fetching guild owner:', error);
            });
    },
};
