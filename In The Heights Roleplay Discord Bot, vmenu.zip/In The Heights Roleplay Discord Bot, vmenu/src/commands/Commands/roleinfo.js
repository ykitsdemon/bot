const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('roleinfo')
        .setDescription('Get information about a role')
        .addRoleOption(option => option
            .setName('role')
            .setDescription('Select the role to get information about')
            .setRequired(true)),
    async execute(interaction) {
        const role = interaction.options.getRole('role');

        const permissions = role.permissions.toArray();
        const permissionList = permissions.length > 0
            ? permissions.map(perm => `\`\`\`${perm}\`\`\``)
            : ['\`\`\`❌ Doesn\'t have permissions\`\`\`'];

        const members = role.members.size;
        const position = role.position;
        const color = role.hexColor;
        const createdDate = role.createdTimestamp;
        const currentDate = Date.now();
        const roleAge = Math.floor((currentDate - createdDate) / (1000 * 60 * 60 * 24));

        const roleInfoEmbed = {
            title: ':construction_worker: ROLE INFORMATION :construction_worker:',
            fields: [
                {
                    name: 'Role name',
                    value: `\`\`\`${role.name}\`\`\``,
                },
                {
                    name: 'Role ID',
                    value: `\`\`\`${role.id}\`\`\``,
                },
                {
                    name: 'Permissions the role has',
                    value: permissionList.join('\n'),
                },
                {
                    name: 'Members',
                    value: `\`\`\`${members}\`\`\``,
                },
                {
                    name: 'Role position',
                    value: `\`\`\`${position}\`\`\``,
                },
                {
                    name: 'Role color',
                    value: `\`\`\`${color}\`\`\``,
                },
                {
                    name: 'Role created on (MM/DD/YYYY)',
                    value: `\`\`\`${new Date(createdDate).toLocaleString('en-US', { timeZone: 'UTC' })} (${roleAge} days ago)\`\`\``,
                },


            ],
            footer: {
                Text: 'Role Information • '+process.env.footerText,
            },
            color: 0xE67E22,
        };

        interaction.reply({ embeds: [roleInfoEmbed] });
    },
};
