const { SlashCommandBuilder } = require('discord.js');

const allowedRoleId = process.env.RoleStripRoleID;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rolestrip')
        .setDescription('Remove all roles from a user')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to remove roles from')
            .setRequired(true)),
    async execute(interaction) {
        const member = interaction.member;
        const allowedRole = interaction.guild.roles.cache.get(allowedRoleId);
       
        if (!member.roles.cache.has(allowedRoleId)) {
            const errorEmbed = {
                color: 0xff0000,
                title: 'Permission Error',
                description: 'You do not have permission to use this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };

            return interaction.reply({ embeds: [errorEmbed] });
        }

        const userToRolestrip = interaction.options.getMember('user'); // Fetch the GuildMember

        try {
            await userToRolestrip.roles.set([]);
        } catch (error) {
            console.error(`Failed to strip roles from user ${userToRolestrip.id}: ${error.message}`);
            const errorEmbed = {
                color: 0xff0000,
                title: 'Role Stripping Error',
                description: `Failed to strip roles from <@${userToRolestrip.id}>.`,
                timestamp: new Date(),
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
            };
            return interaction.reply({ embeds: [errorEmbed] });
        }

        const successEmbed = {
            color: 0x00ff00,
            title: 'Role Stripped',
            description: `Successfully stripped all roles from <@${userToRolestrip.id}>.`,
            timestamp: new Date(),
            footer: {
                text: 'Role Stripped • ' + process.env.footerText,
            },
        };

        interaction.reply({ embeds: [successEmbed] });
    },
};
