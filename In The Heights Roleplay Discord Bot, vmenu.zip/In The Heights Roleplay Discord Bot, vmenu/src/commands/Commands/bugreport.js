const { SlashCommandBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('report')
        .setDescription('Send a bug report'),
    async execute(interaction) {

        const modal = new ModalBuilder()
        .setTitle('Reporting System')
        .setCustomId('bug_report')

        const command = new TextInputBuilder()
        .setCustomId('command')
        .setRequired(true)
        .setPlaceholder('Please only State the User Name Or Error')
        .setLabel('Who or what are you reporting?')
        .setStyle(TextInputStyle.Short);

        const description = new TextInputBuilder()
        .setCustomId('description')
        .setRequired(true)
        .setPlaceholder('Please Describe what ur reporting (Please be as Detailed As Possible)')
        .setLabel('Describe the Report')
        .setStyle(TextInputStyle.Paragraph);

        const one =  new ActionRowBuilder().addComponents(command);
        const two = new ActionRowBuilder().addComponents(description);


        modal.addComponents(one, two);
        await interaction.showModal(modal);
    },
};