const { SlashCommandBuilder } = require('discord.js');

const allowedRoleId = process.env.GlobalNickRole;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('globalnickname')
        .setDescription('Set a global nickname for a user (requires allowed role)')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to set a global nickname for')
            .setRequired(true))
        .addStringOption(option => option
            .setName('nickname')
            .setDescription('New nickname for the user')
            .setRequired(true)),
    async execute(interaction) {
        const member = interaction.member;
        const allowedRole = interaction.guild.roles.cache.get(allowedRoleId);
       
        if (!member.roles.cache.has(allowedRoleId)) {
            const errorEmbed = {
                color: 0xff0000,
                title: 'Permission Error',
                description: 'You do not have the required permissions to use this command.',
                footer: {
                    Text: 'Made By Joe Development',
                },
            };
            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const userToSetNickname = interaction.options.getMember('user');
        const newNickname = interaction.options.getString('nickname') || 'No reason provided';
        let successfulChanges = 0;
        let failedChanges = 0;

        const guilds = [...interaction.client.guilds.cache.values()];

        try {
            const fetchOperations = guilds.map(async (guild) => {
                try {
                    const targetMember = await guild.members.fetch(userToSetNickname.id);
                    if (targetMember) {
                        await targetMember.setNickname(newNickname);
                        successfulChanges++;
                    }
                } catch (error) {
                    console.error(`Failed to set a nickname for user ${userToSetNickname.id} in guild ${guild.name}: ${error.message}`);
                    failedChanges++;
                }
            });

            await Promise.all(fetchOperations);

            const totalGuilds = guilds.length;
            const finalGuildCount = totalGuilds - failedChanges;

            const successEmbed = {
                color: 0x00ff00,
                title: 'Global Nickname Set',
                description: `Successfully set/changed a global nickname for <@${userToSetNickname.id}> `,
                footer: {
                    Text: 'Global NickName • ' + process.env.footerText,
                },
                fields: [
                    {
                        name: 'New Nickname',
                        value: newNickname,
                    },
                    {
                        name: 'Guilds',
                        value: `${successfulChanges} / ${totalGuilds} guilds.`,
                    },
                ],
            };

            interaction.reply({ embeds: [successEmbed] });
        } catch (error) {
            console.error('Error fetching user in guilds:', error);
        }
    },
};
