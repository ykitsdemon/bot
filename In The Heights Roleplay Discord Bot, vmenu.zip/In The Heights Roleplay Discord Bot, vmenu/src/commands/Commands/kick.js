const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a user from the server')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to kick')
            .setRequired(true))
        .addStringOption(option => option
            .setName('reason')
            .setDescription('Reason for the kick')),
    async execute(interaction) {
        const member = interaction.member;
        const kickRoleID = process.env.kickRoleID;
        const allowedRole = interaction.guild.roles.cache.get(kickRoleID);

        if (!member.roles.cache.has(kickRoleID)) {
            const errorEmbed = {
                title: 'Permission Error',
                color: 0xff0000,
                description: 'You do not have permission to use this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • '+process.env.footerText,
                },
            };

            interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return;
        }

        const userToKick = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (userToKick.id === interaction.user.id) {
            const selfKickErrorEmbed = {
                title: 'Self-Kick Error',
                color: 0xff0000,
                description: 'You cannot kick yourself using this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • '+process.env.footerText,
                },
            };

            interaction.reply({ embeds: [selfKickErrorEmbed], ephemeral: true });
            return;
        }

        const targetMember = interaction.guild.members.cache.get(userToKick.id);

        if (targetMember) {
            targetMember.kick(reason)
                .then(() => {
                    const successEmbed = {
                        title: 'User Kicked',
                        color: 0x00ff00,
                        description: `Successfully kicked <@${userToKick.id}> from the server.`,
                        fields: [
                            {
                                name: 'Reason',
                                value: reason,
                            },
                        ],
                        timestamp: new Date(),
                        footer: {
                            text: 'Kicked • '+process.env.footerText,
                        },
                    };

                    interaction.reply({ embeds: [successEmbed] });
                })
                .catch((error) => {
                    console.error(`Failed to kick user ${userToKick.id}: ${error.message}`);
                    const errorEmbed = {
                        title: 'Kick Error',
                        color: 0xff0000,
                        description: `Failed to kick <@${userToKick.id}.`,
                        timestamp: new Date(),
                        footer: {
                            text: 'Error • '+process.env.footerText,
                        },
                    };

                    interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                });
        } else {
            const notFoundEmbed = {
                title: 'User Not Found',
                color: 0xff0000,
                description: 'The specified user was not found in the server.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • '+process.env.footerText,
                },
            };

            interaction.reply({ embeds: [notFoundEmbed], ephemeral: true });
        }
    },
};
