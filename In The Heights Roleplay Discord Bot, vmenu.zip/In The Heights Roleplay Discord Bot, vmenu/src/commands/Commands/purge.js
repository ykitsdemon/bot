const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('purge')
        .setDescription('Delete a specified number of messages')
        .addIntegerOption(option => option
            .setName('messagecount')
            .setDescription('Number of messages to delete')
            .setRequired(true)),
    async execute(interaction) {
        const messageCount = interaction.options.getInteger('messagecount');
        const moderator = `<@${interaction.user.id}>`;

        const authorMember = interaction.member;

        if (!authorMember.roles.cache.some(role => role.id === process.env.purgeRoleID)) {
            const roleErrorEmbed = {
                color: 0xff0000,
                title: 'Role Error',
                description: 'You do not have the required role to use this command.',
                timestamp: new Date(),
                footer: {
                    text: `Error • `+ process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };

            return interaction.reply({ embeds: [roleErrorEmbed] });
        }

        if (messageCount > 100) {
            const maxDeleteErrorEmbed = {
                color: 0xff0000,
                title: 'Message Limit Error',
                description: 'You can only delete up to 100 messages at a time.',
                timestamp: new Date(),
                footer: {
                    text: `Error • `+ process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };

            return interaction.reply({ embeds: [maxDeleteErrorEmbed] });
        }

        try {
            const messages = await interaction.channel.bulkDelete(messageCount, true);

            const successEmbed = {
                color: 0x00ff00,
                title: 'Messages Purged',
                description: `Successfully deleted ${messages.size} messages.`,
                fields: [
                    {
                        name: 'Moderator',
                        value: moderator,
                    },
                ],
                timestamp: new Date(),
                footer: {
                    text: `Purged • `+ process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };

            interaction.reply({ embeds: [successEmbed] });
        } catch (error) {
            console.error(error);

            const deleteErrorEmbed = {
                color: 0xff0000,
                title: 'Deletion Error',
                description: 'An error occurred while trying to delete the messages.',
                timestamp: new Date(),
                footer: {
                    text: `Error • `+ process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };

            interaction.reply({ embeds: [deleteErrorEmbed] });
        }
    },
};
