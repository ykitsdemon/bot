const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlockdown')
    .setDescription('Unlockdown the current channel.')
    .addChannelOption(option => option.setName('channel').setDescription('The channel to unlock.')),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const unlockRoleID = process.env.lockdownChannelRoleID; 
    const error = new EmbedBuilder()
    .setColor('Blurple')
    .setDescription('You do not have the required permissions to use this command. ')
    .setTimestamp()
    .setTitle('Permission Error')
    .setFooter({ text: `Permission Error • ${process.env.footerText}` });

    if (!interaction.member.roles.cache.has(unlockRoleID)) {
      return interaction.reply({ embeds: [error], ephemeral: true });
    }

    const already = new EmbedBuilder()
    .setColor('Blurple')
    .setDescription('This Channel Already Seems to be Unlocked Down ')
    .setTimestamp()
    .setTitle('Error')
    .setFooter({ text: `Error • ${process.env.footerText}` });

    if (channel.permissionsFor(interaction.guild.roles.everyone).has(PermissionsBitField.Flags.SendMessages) === true) {
      return interaction.reply({ embeds: [already], ephemeral: true });
    }

    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
      SendMessages: null
    });

    const embed = new EmbedBuilder()
      .setColor('#2f3136')
      .setTitle(`The channel has been unlocked.`).setDescription(`Channel Name: ${channel}`)
      .setTimestamp()
      .setFooter({ text: `UnLocked Down • ${process.env.footerText}` });

    await interaction.reply({ ephemeral: true, embeds: [embed] });
  },
};
