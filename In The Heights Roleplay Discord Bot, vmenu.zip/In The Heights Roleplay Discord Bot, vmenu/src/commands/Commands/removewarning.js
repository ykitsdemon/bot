const fs = require('fs');
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('removewarning')
        .setDescription('Remove a warning from a user')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Select the user to remove a warning from')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('warning_id')
                .setDescription('Enter the ID of the warning to remove')
                .setRequired(true)),
    async execute(interaction) {
        const userToRemoveWarning = interaction.options.getUser('user');
        const warningIDToRemove = interaction.options.getInteger('warning_id');

        const warnRoleId = process.env.warnRoleID;
        if (!interaction.member.roles.cache.has(warnRoleId)) {
            const errorEmbed = {
                title: 'Permission Error',
                description: 'You do not have permission to use this command.',
                color: 0xff0000,
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
            };

            interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return;
        }

        let warnings = JSON.parse(fs.readFileSync('warnings.json'));

        if (userToRemoveWarning.id in warnings && warnings[userToRemoveWarning.id].length > 0) {
            const userWarnings = warnings[userToRemoveWarning.id];
            const warningIndex = userWarnings.findIndex(warning => warning.id === warningIDToRemove);

            if (warningIndex !== -1) {
                userWarnings.splice(warningIndex, 1);

                fs.writeFileSync('warnings.json', JSON.stringify(warnings, null, 4));

                const successEmbed = {
                    title: 'Warning Removed',
                    description: `**Warning ID: ${warningIDToRemove}** has been removed for ${userToRemoveWarning}.`,
                    color: 0x00ff00,
                    footer: {
                        text: 'Success • ' + process.env.footerText,
                    },
                };

                interaction.reply({ embeds: [successEmbed] });
            } else {
                const errorEmbed = {
                    title: 'Warning Not Found',
                    description: `The warning with ID ${warningIDToRemove} was not found for ${userToRemoveWarning}.`,
                    color: 0xff0000,
                    footer: {
                        text: 'Error • ' + process.env.footerText,
                    },
                };

                interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        } else {
            const errorEmbed = {
                title: 'User Has No Warnings',
                description: `${userToRemoveWarning} has no recorded warnings.`,
                color: 0xff0000,
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
            };

            interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    },
};
