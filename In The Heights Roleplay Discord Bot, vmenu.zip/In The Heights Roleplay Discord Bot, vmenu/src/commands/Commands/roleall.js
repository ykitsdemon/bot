const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('role-all')
        .setDescription('This Command Roles all the users in the discord with the selected role (Please Use Carefully)')
        .addRoleOption(option => option
            .setName('role')
            .setDescription('What You want the Role to be to give all users')
            .setRequired(true)
        ),
    async execute(interaction) {
        const { options, guild } = interaction;
        const members = await guild.members.fetch();
        const roleId = process.env.roleallPermRoleID; 
        const role = options.getRole('role');

        const error = new EmbedBuilder()
            .setTitle('Role All Error')
            .setColor('Red')
            .setTimestamp()
            .setDescription(':interrobang: You do not have the required permissions to use this command.')
            .setFooter({ text: `Role all • ${process.env.footerText}` });

        if (!interaction.member.roles.cache.has(roleId)) {
            return await interaction.reply({ embeds: [error], ephemeral: true });
        } else {
            const ea = new EmbedBuilder()
                .setTitle('Role All')
                .setColor('Blurple')
                .setDescription(`<a:blackandwhite_loading:1167402276512604202> Giving Everyone the ${role.name} role This may take some time, please wait.`)
                .setFooter({ text: `Role all • ${process.env.footerText}` });

            await interaction.reply({ embeds: [ea] });

            let num = 0;
            setTimeout(() => {
                members.forEach(async (m) => {
                    m.roles.add(role).catch((err) => {
                        console.log('Catched an error in progress', err);
                    });
                    num++;

                    const embed = new EmbedBuilder()
                    .setTitle('Role All')
                        .setColor('Blurple')
                        .setTimestamp()
                        .setDescription(`✅ ${num} members now have the <@&${role.id}> Role`)
                        .setFooter({ text: `Role all • ${process.env.footerText}` });

                    await interaction.editReply({ embeds: [embed], content: '' });
                });
            }, 100);
        }
    },
};
