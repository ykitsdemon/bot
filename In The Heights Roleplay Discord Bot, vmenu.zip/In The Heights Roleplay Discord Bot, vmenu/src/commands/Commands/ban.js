const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a user from the server')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to ban')
            .setRequired(true))
        .addStringOption(option => option
            .setName('reason')
            .setDescription('Reason for the ban')),
    async execute(interaction) {
        const member = interaction.member;
        const banRoleID = process.env.banRoleID;
        const allowedRole = interaction.guild.roles.cache.get(banRoleID);

        if (!member.roles.cache.has(banRoleID)) {
            const errorEmbed = {
                title: 'Permission Error',
                color: 0xff0000,
                description: 'You do not have permission to use this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • '+process.env.footerText,
                },
            };

            interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return;
        }

        const userToBan = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (userToBan.id === interaction.user.id) {
            const selfBanErrorEmbed = {
                title: 'Self-Ban Error',
                color: 0xff0000,
                description: 'You cannot ban yourself using this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • '+process.env.footerText,
                },
            };

            interaction.reply({ embeds: [selfBanErrorEmbed], ephemeral: true });
            return;
        }

        const targetMember = interaction.guild.members.cache.get(userToBan.id);

        if (targetMember) {
            targetMember.ban({ reason: reason })
                .then(() => {
                    const successEmbed = {
                        title: 'User Banned',
                        color: 0x00ff00,
                        description: `Successfully banned <@${userToBan.id}> from the server.`,
                        fields: [
                            {
                                name: 'Reason',
                                value: reason,
                            },
                        ],
                        timestamp: new Date(),
                        footer: {
                            text: 'Banned • '+process.env.footerText,
                        },
                    };

                    interaction.reply({ embeds: [successEmbed] });
                })
                .catch((error) => {
                    console.error(`Failed to ban user ${userToBan.id}: ${error.message}`);
                    const errorEmbed = {
                        title: 'Ban Error',
                        color: 0xff0000,
                        description: `Failed to ban <@${userToBan.id}.`,
                        timestamp: new Date(),
                        footer: {
                            text: 'Error • '+process.env.footerText,
                        },
                    };

                    interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                });

        }
    },
};
