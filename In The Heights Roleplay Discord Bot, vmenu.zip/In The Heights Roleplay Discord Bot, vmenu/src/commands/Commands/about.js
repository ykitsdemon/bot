const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('uptime')
        .setDescription('Check the bot\'s uptime'),
    async execute(interaction) {
        const client = interaction.client;
        const uptimeMs = client.uptime;
        const days = Math.floor(uptimeMs / 86400000);
        const hours = Math.floor((uptimeMs % 86400000) / 3600000);
        const minutes = Math.floor((uptimeMs % 3600000) / 60000);
        const seconds = Math.floor((uptimeMs % 60000) / 1000);

        const embed = {
            title: "About "+ process.env.footerText + "",
            color: 0xFF0000,
            description: "**"+ process.env.footerText + '** Bot is a bot created by <@1145944873149661275> to help manage Servers as a FiveM / Community UTIL Discord Bot.',
            timestamp: new Date(),
            footer: {
                text: process.env.footerText,
            },
            fields: [
                {
                    name: "Uptime",
                    value: `\`${days}\` days, \`${hours}\` hours, \`${minutes}\` minutes, and \`${seconds}\` seconds.`,
                },
            ],
        };

        await interaction.reply({ embeds: [embed] });
    },
};
