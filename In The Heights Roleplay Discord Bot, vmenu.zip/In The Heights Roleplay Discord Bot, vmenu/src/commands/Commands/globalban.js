const { SlashCommandBuilder } = require('discord.js');

const allowedRoleId = process.env.globalBanRole; 

module.exports = {
    data: new SlashCommandBuilder()
        .setName('globalban')
        .setDescription('Ban a user from all guilds the bot is in')
        .addUserOption(option => option
            .setName('user')
            .setDescription('Select the user to global ban')
            .setRequired(true))
        .addStringOption(option => option
            .setName('reason')
            .setDescription('Reason for the global ban')
            .setRequired(true)),
    async execute(interaction) {
        const member = interaction.member;
        const allowedRole = interaction.guild.roles.cache.get(allowedRoleId);
        if (!member.roles.cache.has(allowedRoleId)) {
            const errorEmbed = {
                color: 0xff0000,
                title: 'Permission Error',
                description: 'You do not have permission to use this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • '+process.env.footerText,
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                }
            };

            return interaction.reply({ embeds: [errorEmbed] });
        }

        const userToBan = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        if (userToBan.id === interaction.user.id) {
            const selfBanErrorEmbed = {
                color: 0xff0000,
                title: 'Self-Ban Error',
                description: 'You cannot globally ban yourself using this command.',
                timestamp: new Date(),
                footer: {
                    text: 'Error • NexusGuard',
                },
                thumbnail: {
                    url: interaction.user.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
                },
            };
            return interaction.reply({ embeds: [selfBanErrorEmbed] });
        }
        

        interaction.client.guilds.cache.forEach(async (guild) => {
            try {
                await guild.members.ban(userToBan, { reason });
            } catch (error) {
                console.error(`Failed to ban user ${userToBan.id} from guild ${guild.name}: ${error.message}`);
            }
        });

        const successEmbed = {
            color: 0x00ff00,
            title: 'User Globally Banned',
            description: `Successfully globally banned <@${userToBan.id}> from all guilds the bot is in.`,
            fields: [
                {
                    name: 'Reason',
                    value: reason,
                },
                {
                    name: 'Banned in Guilds',
                    value: ` ${interaction.client.guilds.cache.size} / ${interaction.client.guilds.cache.size} guilds`,
                },
            ],
            timestamp: new Date(),
            footer: {
                text: 'Globally Banned • '+process.env.footerText,
            },
            thumbnail: {
                url: userToBan.displayAvatarURL({ dynamic: true, format: 'png', size: 512 }),
            },
        };

        interaction.reply({ embeds: [successEmbed] });
    },
};
