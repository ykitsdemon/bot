const fs = require('fs');
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warninfo')
        .setDescription('View warnings for a user')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Select the user to view warnings for')
                .setRequired(true)),
    async execute(interaction) {
        const userToViewWarnings = interaction.options.getUser('user');

        const warnRoleId = process.env.warnRoleID;
        if (!interaction.member.roles.cache.has(warnRoleId)) {
            const errorEmbed = {
                title: 'Permission Error',
                description: 'You do not have permission to use this command.',
                color: 0xff0000,
                footer: {
                    text: 'Error • ' + process.env.footerText,
                },
            };

            interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return;
        }

        let warnings = JSON.parse(fs.readFileSync('warnings.json'));

        if (userToViewWarnings.id in warnings && warnings[userToViewWarnings.id].length > 0) {
            const userWarnings = warnings[userToViewWarnings.id];
            const warningEmbeds = userWarnings.map((warning, index) => ({
                title: `Warning ID: ${warning.id}`,
                description: `Details of Warning ${index + 1}`,
                color: 0xff0000,
                fields: [
                    {
                        name: 'Moderator',
                        value: `<@${interaction.user.id}>`,
                        inline: true,
                    },
                    {
                        name: 'Reason',
                        value: warning.reason,
                        inline: true,
                    },
                    {
                        name: 'Timestamp',
                        value: new Date(warning.timestamp).toLocaleString(),
                        inline: true,
                    },
                ],
                footer: {
                    text: `Warning ${index + 1}/${userWarnings.length} • ${process.env.footerText}`,
                },
            }));

            interaction.reply({ embeds: warningEmbeds });
        } else {
            const errorEmbed = {
                title: 'No Warnings Found',
                description: `${userToViewWarnings} has no recorded warnings.`,
                color: 0x00ff00,
                footer: {
                    text: 'Success • ' + process.env.footerText,
                },
            };

            interaction.reply({ embeds: [errorEmbed] });
        }
    },
};
