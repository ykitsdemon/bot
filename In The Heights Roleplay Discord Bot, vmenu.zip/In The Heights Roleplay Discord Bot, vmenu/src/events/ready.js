const colorette = require('colorette');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(colorette.green(`Bot is Online and ready as [${client.user.tag}]`));

        const { ActivityType } = require("discord.js");

        function updateActivity() {
            const totalGuilds = client.guilds.cache.size;
            let totalMembers = 0;
            let totalChannels = 0;
            let totalRoles = 0;
        
            client.guilds.cache.forEach(guild => {
                totalMembers += guild.memberCount; 
                totalChannels += guild.channels.cache.size;
                totalRoles += guild.roles.cache.size;
            });
        
            const activities = [
                { name: `${totalGuilds} Guilds`, type: ActivityType.Watching },
                { name: `${totalMembers} Total Members`, type: ActivityType.Watching },
                { name: `${totalChannels} Channels`, type: ActivityType.Streaming },
                { name: `${totalRoles} Roles`, type: ActivityType.Streaming }
            ];
        
            let index = 0;
        
            function setActivity() {
                const activity = activities[index];
                client.user.setActivity({ name: activity.name, type: activity.type });
                index = (index + 1) % activities.length;
            }
        
            setActivity();
            setInterval(setActivity, 5000);
        }
        
        updateActivity();
        async function pickPresence () {
            const option = Math.floor(Math.random() * statusArray.length);

            try {
                await client.user.setPresence({
                    activities: [
                        {
                            name: statusArray[option].content,
                            type: statusArray[option].type,

                        },
                    
                    ],

                    status: statusArray[option].status
                })
            } catch (error) {
                console.error(error);
            }
        }
    },
};